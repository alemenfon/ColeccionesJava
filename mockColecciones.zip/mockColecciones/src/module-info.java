/**
 * 
 */
/**
 * 
 */
module mockColecciones {
}