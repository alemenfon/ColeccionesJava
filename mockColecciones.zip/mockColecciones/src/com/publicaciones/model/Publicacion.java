package com.publicaciones.model;

import java.time.LocalDateTime;
import java.util.Objects;

public abstract class Publicacion implements Valorable, Comparable<Publicacion> {
	
	protected String texto;
	private LocalDateTime fechaCreacion;
	protected int valoracion;
	private int codigo;
	private static int codigoSiguiente;
	private Usuario usuario;
	
	
	public Publicacion(String texto, Usuario usuario) {
		super();
		this.texto = texto;
		this.fechaCreacion=LocalDateTime.now();
		this.codigo=codigoSiguiente++;
		this.usuario = usuario;
	}
	
	protected String getTexto() {
		return this.texto;
	}
	
	protected abstract void setTexto(String texto) throws PublicacionException;

	@Override
	public int hashCode() {
		return Objects.hash(codigo, fechaCreacion, texto, usuario, valoracion);
	}

	@Override
	public boolean equals(Object obj) {
		
		Publicacion other = (Publicacion) obj;
		return codigo == other.codigo && Objects.equals(fechaCreacion, other.fechaCreacion)
				&& Objects.equals(texto, other.texto) && Objects.equals(usuario, other.usuario)
				&& valoracion == other.valoracion;
	}

	public LocalDateTime getFechaCreacion() {
		return fechaCreacion;
	}

	public int getValoracion() {
		return valoracion;
	}

	public int getCodigo() {
		return codigo;
	}
	
	public String getLoginUsuario() {
		return this.usuario.getLogin();
	}
	
	

	@Override
	public int compareTo(Publicacion o) {
		return this.fechaCreacion.compareTo(o.getFechaCreacion());
	}
	
	public boolean isAnterior(Publicacion publicacion) {
		return this.fechaCreacion.compareTo(publicacion.getFechaCreacion()) > 0;
	}
	
	
	

	@Override
	public String toString() {
		return String.format("Publicación: %s \r\n"
				+ "Realizada por: %s \r\n"
				+ "Valoración: %s \r\n"
				+ "Fecha de publicación: %s ", this.texto, getLoginUsuario(),getValoracion(),getFechaCreacion());
	}
	
	
	
	
	

}
