package com.publicaciones.model;

import java.util.Objects;


public class Usuario {
	
	private String login;
	private String pass;
	
	
	public Usuario(String login, String pass) {
		super();
		this.login = login;
		this.pass = pass;
	}


	public String getLogin() {
		return login;
	}


	public void setPass(String oldPass, String newPass) {
		
	}
		
	
	
	public boolean checkPass(String pass) {
		return false;
		
	}


	@Override
	public int hashCode() {
		return Objects.hash(login, pass);
	}


	@Override
	public boolean equals(Object obj) {
		boolean sonIguales=this==obj;
		if(!sonIguales && obj!=null && obj instanceof Usuario) {
			Usuario other = (Usuario)obj;
			sonIguales=this.getLogin()!=null && other.getLogin()!=null 
					&& this.getLogin().equalsIgnoreCase(login);
		}
		return sonIguales;
	}
	
	
	

}
