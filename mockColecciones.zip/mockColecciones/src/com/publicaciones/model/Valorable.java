package com.publicaciones.model;

public interface Valorable {
	
	public boolean valorar(String valoracion);

}
