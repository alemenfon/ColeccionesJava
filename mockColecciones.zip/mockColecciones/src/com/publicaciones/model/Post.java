package com.publicaciones.model;

public class Post extends Publicacion {
	private int numeroLecturas;
	private String tema;

	public Post(String texto, Usuario usuario,String tema) {
		super(texto, usuario);
		this.tema=tema;
		
	}

	@Override
	public boolean valorar(String valoracion) {
		
		return false;
	}

	@Override
	protected void setTexto(String texto) throws PublicacionException {
		if(texto.isBlank()) {
			throw new PublicacionException("El post no puede estar en blanco");
			
		}
		
		
	}

	public int getNumeroLecturas() {
		return numeroLecturas;
	}

	@Override
	public String toString() {
		return String.format("Post.\r\n"
				+ "Publicación: %s \r\n"
				+ "Realizada por: %s \r\n"
				+ "Valoración: %s \r\n"
				+ "Fecha de publicación: %s ", this.texto,getLoginUsuario(),getValoracion(),getFechaCreacion());
	}

	@Override
	public int compareTo(Publicacion o) {
		return numeroLecturas;
		
		
	}
	
	

}
