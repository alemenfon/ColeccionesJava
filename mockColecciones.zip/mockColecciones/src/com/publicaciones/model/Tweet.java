package com.publicaciones.model;

public class Tweet extends Publicacion {

	public Tweet(String texto, Usuario usuario) {
		super(texto, usuario);
		
	}

	@Override
	protected void setTexto(String texto) throws PublicacionException  {
		if(texto!=null && texto.length()>50) {
			throw new PublicacionException("Ha superado el máximo de caracteres permitidos.");	
		}
		this.texto=texto;
		
	}

	@Override
	public boolean valorar(String valoracion) {
		
		return false;
	}

	@Override
	public String toString() {
		return String.format("Tweet.\r\n"
				+ "Publicación: %s \r\n"
				+ "Realizada por:  %s \r\n"
				+ "Valoración:  %s \r\n"
				+ "Fecha de publicación: %s ", this.texto,getLoginUsuario(),getValoracion(),getFechaCreacion());
	}
	
	

}
