package com.publicaciones.model;

import java.util.ArrayList;
import java.util.List;

public class MemoryStorage {
	
	private static final  int NUM_MAXIMO_USUARIOS =         15;
	private static final  int NUM_MAXIMO_PUBLICACIONES =    50;
	
	private int numUsuariosActuales;
	private int numPublicacionesActuales;
	
	private List<Usuario> usuarios;
	private List<Publicacion> publicaciones;
	
	public MemoryStorage() {
		this.publicaciones = new ArrayList<>();
		
	}
	
	private void posicionUsuario() {
		return ;
	}
	
	private void addUsuario(Usuario u) throws MemoryStorageException {
		if(usuarios.size()>NUM_MAXIMO_USUARIOS) {
			throw new MemoryStorageException("Capacidad máxima de usuarios.");	
		}
		
		for(Usuario usu: this.usuarios) {
			if(usu.getLogin().equals(u.getLogin())) {
				throw new MemoryStorageException("Usuario existente");		
			}
			this.usuarios.add(u);
			
		}
			
				
	}
	
	public void addPublicacion(Publicacion publi) {
		if(publicaciones.size()>NUM_MAXIMO_PUBLICACIONES) {
			eliminarPublicacionMasAntigua();
		}else {
			publicaciones.add(publi);
			
		}
		
		
	}
	
	private void eliminarPublicacionMasAntigua() {
	    Publicacion publiMasAntigua = publicaciones.get(0);
	    for (Publicacion publi : this.publicaciones) {
	        if (publi.isAnterior(publiMasAntigua)) {
	            publiMasAntigua = publi;
	        }
	    }
	    publicaciones.remove(publiMasAntigua);
	}
	
	 public void mostrarListaPublicaciones() {
	        System.out.println("Lista de Publicaciones:");
	        if(publicaciones!=null) {
	        	for (Publicacion publicacion : publicaciones) {
		            System.out.println(publicacion);	
	        }	
	        
	        }else {
	        	System.out.println("No existen publicaciones");
	        }
	    }
	 
	 public void mostrarListaTweets() {
	        System.out.println("Lista de Tweets:");
	        if(publicaciones!=null) {
	        	for (Publicacion publicacion : publicaciones) {
	        		if(publicacion instanceof Tweet) {
	        			System.out.println(publicacion);	
	        		}     	
	        }	
	        
	        }else {
	        	System.out.println("No existen Tweets");
	        }
	    }
	 
	 public void mostrarListaPost() {
	        System.out.println("Lista de Posts:");
	        if(publicaciones!=null) {
	        	for (Publicacion publicacion : publicaciones) {
	        		if(publicacion instanceof Post) {
	        			System.out.println(publicacion);	
	        		}     	
	        }	
	        
	        }else {
	        	System.out.println("No existen Post");
	        }
	    }
	 
	 public void mostrarRecomendaciones() {
	        System.out.println("Recomendaciones: ");
	        if(publicaciones!=null) {
	        	for (Publicacion publicacion : publicaciones) {
	        		if(publicacion instanceof Recomendacion) {
	        			System.out.println(publicacion);	
	        		}     	
	        }	
	        
	        }else {
	        	System.out.println("No existen recomendaciones");
	        }
	    }
	 
	 
			
				
						
}
		
	
	
	

	
	

