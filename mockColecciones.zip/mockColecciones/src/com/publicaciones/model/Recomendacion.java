package com.publicaciones.model;

public class Recomendacion extends Publicacion {
	
	private int numEstrellas;

	public Recomendacion(String texto, Usuario usuario, int numeroEstrellas) throws PublicacionException {
		super(texto, usuario);
		this.numEstrellas=numeroEstrellas;
		if(numEstrellas>5 || numEstrellas<1) {
			throw new PublicacionException("El numero de eestrellas debe estar entre 1 y 5");
		}
		
		
	}

	@Override
	protected void setTexto(String texto) throws PublicacionException {	
		if(texto.length()<100 || texto.length()>200) {
			throw new PublicacionException("Las recomendaciones tienen un mínimo de 100 y máximo de 200 caracteres");
			
		}
	}
	

	public int getNumEstrellas(){	
		return numEstrellas;
	}
	
	

	public void setNumEstrellas(int numEstrellas) {
		this.numEstrellas = numEstrellas;
	}

	@Override
	public String toString() {
		return String.format("Publicación: %s \r\n"
				+ "Realizada por: %s \r\n"
				+ "Valoración: %s \r\n"
				+ "Fecha de publicación: %s \r\n"
				+ "Número de estrellas: %s", this.texto, getLoginUsuario(),getValoracion(),getFechaCreacion(),getNumEstrellas());
	}

	@Override
	public boolean valorar(String valoracion) {
		
		return false;
	}

	
	
	
	

}
