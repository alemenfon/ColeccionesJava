package com.publicaciones;

import com.publicaciones.model.MemoryStorageException;
import com.publicaciones.model.Post;
import com.publicaciones.model.Publicacion;
import com.publicaciones.model.PublicacionException;
import com.publicaciones.model.Tweet;
import com.publicaciones.model.Usuario;
import com.publicaciones.model.MemoryStorage;

public class MainPubli {


	public static void main(String[] args) {
		
		Usuario usuario1 = new Usuario("Alejandra", "alemenfon");
		Publicacion p = new Tweet("Texto para Tweet", usuario1);
		p.valorar("BUENA");
		System.out.println(p.getFechaCreacion());
		System.out.println(p.getValoracion());
		
		MemoryStorage ms = new MemoryStorage();
		ms.addPublicacion(p);
		ms.mostrarListaPublicaciones();
		ms.mostrarListaPost();
		ms.mostrarRecomendaciones();
		
		
		
	
	}

}
